# Flutter SQFlite

<p>
<img src="https://user-images.githubusercontent.com/30998350/54428205-bdd86580-4742-11e9-9067-7be32f027023.png" alt="Android" width="250" height="450">&nbsp&nbsp&nbsp
<img src="https://user-images.githubusercontent.com/30998350/57618981-6a4b9200-75a2-11e9-9a53-b82d07102a6e.png" alt="Ios" width="250" height="450">&nbsp&nbsp&nbsp
<img src="https://user-images.githubusercontent.com/30998350/57619473-a2070980-75a3-11e9-9bdd-b1fd1751c4d9.png" alt="Edit" width="250" height="450">
</p>

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://flutter.io/docs/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://flutter.io/docs/cookbook)

For help getting started with Flutter, view our 
[online documentation](https://flutter.io/docs), which offers tutorials, 
samples, guidance on mobile development, and a full API reference.
